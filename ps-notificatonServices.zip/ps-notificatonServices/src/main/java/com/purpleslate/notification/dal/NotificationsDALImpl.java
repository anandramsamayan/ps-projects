package com.purpleslate.notification.dal;

import java.util.List;

import org.bson.Document;
import org.bson.conversions.Bson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;



@Repository
public class NotificationsDALImpl implements NotificationsDAL {

	@Autowired
	private MongoTemplate mongoTemplate;	

	@Override
	public List<NotificationVO> getAllFuturedatedNotifications() {
		// TODO Auto-generated method stub
		Query query = new Query();
		query.addCriteria(Criteria.where("isFutureDated").is("Yes"));
		return mongoTemplate.find(query, NotificationVO.class);
		
	}

	@Override
	public void insertNotification(NotificationVO notificationVO) {
		// TODO Auto-generated method stub
		mongoTemplate.save(notificationVO);
	}

	@Override
	public NotificationVO updateSubmittedSyncNotifications(NotificationVO notificationVO) {
		// TODO Auto-generated method stub
		
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(notificationVO.getId()));
		query.fields().include("id");
		System.out.println("notificationVOdb status - " + notificationVO.getStatus());
		query.addCriteria(Criteria.where("status").is(notificationVO.getStatus()));
		query.fields().include("status");

		NotificationVO notificationVOdb = mongoTemplate.findOne(query, NotificationVO.class);
		System.out.println("notificationVOdb - " + notificationVOdb);

		Update update = new Update();
		update.set("status", notificationVOdb.getStatus()+"->"+"Processed");

		mongoTemplate.updateFirst(query, update, NotificationVO.class);

		//returns everything
		Query query1 = new Query();
		query1.addCriteria(Criteria.where("id").is(notificationVO.getId()));

		NotificationVO notificationVOUpdated = mongoTemplate.findOne(query1, NotificationVO.class);
		System.out.println("notificationVOUpdated - " + notificationVOUpdated);
		return notificationVOUpdated;
	}
	
	
	@Override
	public NotificationVO updateSubmittedAsyncNotifications(NotificationVO notificationVO) {
		// TODO Auto-generated method stub
		notificationVO.setStatus("Submitted->Processing");
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(notificationVO.getId()));
		query.fields().include("id");
		System.out.println("notificationVOdb status - " + notificationVO.getStatus());
		query.addCriteria(Criteria.where("status").is(notificationVO.getStatus()));
		query.fields().include("status");

		NotificationVO notificationVOdb = mongoTemplate.findOne(query, NotificationVO.class);
		System.out.println("notificationVOdb - " + notificationVOdb);

		Update update = new Update();
		update.set("status", notificationVOdb.getStatus()+"->"+"Processed");

		mongoTemplate.updateFirst(query, update, NotificationVO.class);

		//returns everything
		Query query1 = new Query();
		query1.addCriteria(Criteria.where("id").is(notificationVO.getId()));

		NotificationVO notificationVOUpdated = mongoTemplate.findOne(query1, NotificationVO.class);
		System.out.println("notificationVOUpdated - " + notificationVOUpdated);
		return notificationVOUpdated;
	}

}
