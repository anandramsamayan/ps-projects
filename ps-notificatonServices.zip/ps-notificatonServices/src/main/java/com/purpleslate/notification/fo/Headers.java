package com.purpleslate.notification.fo;

public class Headers {

	 private String replyTo;


	 // Getter Methods 

	 public String getReply() {
	  return replyTo;
	 }

	 // Setter Methods 

	 public void setReplyTo(String replyTo) {
	  this.replyTo = replyTo;
	 }
}
